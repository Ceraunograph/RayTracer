#ifndef SCENE_H
#define SCENE_H

class Scene {
	void render();
};

#endif