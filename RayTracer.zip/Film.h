class Film {
public:
	void commit(Sample& sample, Color& color);
	void writeImage();
};