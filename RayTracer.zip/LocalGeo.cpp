#include "LocalGeo.h"

void LocalGeo::setValue(Point _pos, Normal _normal) {
	pos = _pos;
	normal = _normal;
}