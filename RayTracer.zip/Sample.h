#ifndef SAMPLE_H
#define SAMPLE_H

class Sample {
public:
	float x, y;
	void setValue(float x, float y);
};

#endif