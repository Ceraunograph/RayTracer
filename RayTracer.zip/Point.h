#ifndef POINT_H
#define POINT_H

class Point {
public:
	float x, y, z;
	void setValue(float x, float y, float z);
};

#endif