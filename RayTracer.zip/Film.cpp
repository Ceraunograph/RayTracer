#include "Sample.h"
#include "Color.h"

void commit(Sample& sample, Color& color) {
}

void writeImage() {
}