#include "Point.h"

void Point::setValue(float _x, float _y, float _z) {
	x = _x;
	y = _y;
	z = _z;
}