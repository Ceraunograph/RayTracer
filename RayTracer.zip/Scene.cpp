#include "Scene.h"

void Scene::render() {
}