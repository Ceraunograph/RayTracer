#include "Sample.h"

void Sample::setValue(float _x, float _y) {
	x = _x;
	y = _y;
}